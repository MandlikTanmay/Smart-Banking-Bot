import io
from tkinter import *
# import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import cv2
import numpy as np
import os
from os.path import isfile, join
from threading import Thread
from . import face_unlocker as FU
import subprocess

def run_file(file_path):
    try:
        subprocess.run(['python', file_path], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")
    except FileNotFoundError:
        print(f"Error: File not found at '{file_path}'")
    except Exception as e:
        print(f"Error: {e}")

# if __name__ == "__main__":
    # file_to_run = "my_file.py"  # Change this to the actual file path you want to run
    # run_file(file_to_run)



background, textColor = 'black', '#F6FAFB'
background, textColor = textColor, background

avatarChoosen = 0
choosedAvtrImage = None
user_name = ''
user_gender = ''

try:
	face_classifier = cv2.CascadeClassifier('Cascade/haarcascade_frontalface_default.xml')
except Exception as e:
	print('Cascade File is missing...')
	raise SystemExit

if os.path.exists('userData')==False:
	os.mkdir('userData')
	
if os.path.exists('userData/faceData')==False:
	os.mkdir('userData/faceData')

file_to_run = "Face/GUIASSISTANT.py"	

###### ROOT1 ########
def startLogin():		
	try:
		result = FU.startDetecting()
		if result:
			# user = UserData()
			# user.extractData()
			# userName = user.getName().split()[0]
			welcLbl['text'] = 'Hi '+" TVS"+',\nWelcome to the world of\nScience & Technology'
			loginStatus['text'] = 'UNLOCKED'
			loginStatus['fg'] = 'green'
			faceStatus['text']='(Logged In)'
			run_file(file_to_run)
			  # Change this to the actual file path you want to run
    		
		else:
			print('Error Occurred')

	except Exception as e:
		print(e)

#Root
def trainFace():
	data_path = 'userData/faceData/'
	onlyfiles = [f for f in os.listdir(data_path) if isfile(join(data_path, f))]

	Training_data = []
	Labels = []

	for i, files in enumerate(onlyfiles):
		image_path = data_path + onlyfiles[i]
		images = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
		
		Training_data.append(np.asarray(images, dtype=np.uint8))
		Labels.append(i)


	Labels = np.asarray(Labels, dtype=np.int32)

	model = cv2.face.LBPHFaceRecognizer_create()
	model.train(np.asarray(Training_data), np.asarray(Labels))

	print('Model Trained Successfully !!!')
	model.save('userData/trainer.yml')
	print('Model Saved !!!')


def face_extractor(img):
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	faces = face_classifier.detectMultiScale(gray, 1.3, 5)

	if faces == ():
		return None

	for (x, y, w, h) in faces:
		cropped_face = img[y:y+h, x:x+w]

	return cropped_face


cap = None
count = 0
def startCapturing():
	global count, frame
	_, frame = cap.read()
	if face_extractor(frame) is not None:
		count += 1
		face = cv2.resize(face_extractor(frame), (200, 200))
		face = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)

		file_name_path = 'userData/faceData/img' + str(count) + '.png'
		cv2.imwrite(file_name_path, face)
		print(count)
		progress_bar['value'] = count

		cv2.putText(face, str(count), (50, 50), cv2.FONT_HERSHEY_COMPLEX, 1, (0,255,0), 2)
	else:
		pass


	if count==100:
		progress_bar.destroy()
		lmain['image'] = defaultImg2
		statusLbl['text'] = '(Face added successfully)'
		cap.release()
		cv2.destroyAllWindows()
		Thread(target=trainFace).start()
		addBtn['text'] = '        Next        '
		addBtn['command'] = lambda:raise_frame(root3)
		return
	
	frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
	frame = cv2.flip(frame, 1)
	img = Image.fromarray(frame)
	imgtk = ImageTk.PhotoImage(image=img)
	lmain.imgtk = imgtk
	lmain.configure(image=imgtk)
	lmain.after(10, startCapturing)

def Add_Face():

	global cap, user_name, user_gender
	user_name = nameField.get()
	user_gender = r.get()
	if user_name != '' and user_gender!=0:
		if agr.get()==1:
			cap = cv2.VideoCapture(0)
			startCapturing()
			progress_bar.place(x=20, y=273)
			statusLbl['text'] = ''
		else:
			statusLbl['text'] = '(Check the Condition)'
	else:
		statusLbl['text'] = '(Please fill the details)'
full_name = ''
age_info =''
mail_info = ''

def save_info():
    global full_name, age_info, mail_info
    
    full_name = fullnamentry.get()

    age_info = agentry.get()

    mail_info = mailentry.get()

    print(full_name,age_info,mail_info)

    file = open("QR code\Tanmay.text","w")
    
    file.write("Your Full Name : " + full_name)

    file.write("\n")

    file.write("Your Age : "+ (age_info))
    file.close()

    file1 = open("QR code\Tanmay.txt","w")
    file1.write(mail_info)
    file1.close() 
    
    warn() 
    print('Entry saved')
    
    
def warn():
	if full_name != "":
		print("Name Filled!")
		if age_info != (''):
			print('Age Filled!')
			if mail_info != "" :
				print("mail correct!")
				try:
					Generator_2()
					send_attachment_3()
				except:
					print('Enter your Mail ID correctly!')
					fillwarn['text'] = '(Enter your Mail ID correctly!)'
			else:
				print('Enter your mail ID')
				fillwarn['text'] = '(Enter your mail ID)'
		else:
			print('Enter your Age')	
			fillwarn['text'] = '(Enter your Age)'
	else:
		print("Enter your Full Name")
		fillwarn['text'] = '(Enter your Full Name)'

	
#Root5



def Generator_2():
    import qrcode
    with open('QR code\Tanmay.text',"r") as fname:
        data = fname.readlines()   
        print(data)
    string = ''.join(data)
    print(string)
    fillwarn['text'] = '(Generating QR Code...)'
    features =qrcode.QRCode(version = 2,box_size = 20,border = 3)
        
    features.add_data(string)
    features.make(fit =True)
    generate_image = features.make_image(fill_color = "black",back_color = 'White')
    generate_image.save ('QR code\QR-Code.png')
    print("QR Generated")


def send_attachment_3():
    import smtplib
    import re
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders

    with open('QR code\Tanmay.txt',"r") as fname:
        data = fname.readlines()   
        print(data)
    string = ''.join(data)
    print(string)
    clean_data = string 

    remove_blank_space= re.sub(r'\s+', '', clean_data)

    print(remove_blank_space)

    fromaddr = "tanmaymandlik974@gmail.com"
    password = "morndvawglogegpj"
    toaddr = remove_blank_space

    msg = MIMEMultipart()

    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Scan Quick Response Code For Futher Authentication Process"

    body = "Body_of_the_mail"

    msg.attach(MIMEText(body, 'image'))

    filename = "QR code\QR-Code.png"
    attachment = open("QR code\QR-Code.png", "rb")

    p = MIMEBase('application', 'octet-stream')

    p.set_payload((attachment).read())

    encoders.encode_base64(p)

    p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    msg.attach(p)

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(fromaddr,password)

    text1 = msg.as_string()

    server.send_message(msg)

    server.quit()
    print('QR Code sent!')
    fillwarn['text'] = '(QR Sent! Check your mail)'
    fillwarn['text'] = '(Click on Next to Scan QR code)'
    

cap2 =cv2.VideoCapture(0)
def update():
    global frame2, cap2, contents, string
    with open('QR code\Tanmay.text', "r") as fname:
        data = fname.readlines()
    string = ''.join(data)
    
    detector = cv2.QRCodeDetector()
    ret, frame2 = cap2.read()
    # if not ret:
    #     print("Error: Unable to capture frame.")
    #     cap.release()  # Release the video capture object
    #     return
    data, ret,_ = detector.detectAndDecode(frame2)
    if data:
        a = data
        contents = a.strip()  
        if contents == string:
            raise_frame(root4)
        else:
            print("Match not found")

    frame2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2RGBA)
    frame2 = cv2.flip(frame2, 1)
    img2 = Image.fromarray(frame2)
    photo_image = ImageTk.PhotoImage(image=img2)
    label_widget.photo_image = photo_image
    label_widget.configure(image=photo_image)
    label_widget.after(10, update)

    

# def SuccessfullyRegistered():
# 	if avatarChoosen != 0:
# 		gen = 'Male'
# 		if user_gender==2: gen = 'Female'
# 		u = UserData()
# 		u.updateData(user_name, gen)
# 		usernameLbl['text'] = user_name
# 		raise_frame(root4)
		

def raise_frame(frame):
	frame.tkraise()

#MainScreen

root = Tk()
root.title('F.R.I.D.A.Y.')
w_width, w_height = 350, 600
s_width, s_height = root.winfo_screenwidth(), root.winfo_screenheight()
x, y = (s_width/2)-(w_width/2), (s_height/2)-(w_height/2)
root.geometry('%dx%d+%d+%d' % (w_width,w_height,x,y-30)) #center location of the screen
root.configure(bg=background)
# root.attributes('-toolwindow', True)
root1 = Frame(root, bg=background)
root2 = Frame(root, bg=background)
root3 = Frame(root, bg=background)
root4 = Frame(root, bg=background)

for f in (root1, root2, root3, root4):
	f.grid(row=0, column=0, sticky='news')	
	
################################
########  MAIN SCREEN  #########
################################

image1 = Image.open('assets/images/home2.jpg')
image1 = image1.resize((300,250))
defaultImg1 = ImageTk.PhotoImage(image1)

dataFrame1 = Frame(root1, bd=10, bg=background)
dataFrame1.pack()
logo = Label(dataFrame1, width=300, height=250, image=defaultImg1)
logo.pack(padx=10, pady=10)

#welcome label
welcLbl = Label(root1, text='Hi there,\nWelcome to the world of\nScience & Technology', font=('Arial Bold', 15), fg='#303E54', bg=background)
welcLbl.pack(padx=10, pady=20)

#add face
loginStatus = Label(root1, text='LOCKED', font=('Arial Bold', 15), bg=background, fg='red')
loginStatus.pack(pady=(40,20))	

if os.path.exists('userData/trainer.yml')==False:
	loginStatus['text'] = 'Your Face is not registered'
	addFace = Button(root1, text='   Register Face   ', font=('Arial', 12), bg='#018384', fg='white', relief=FLAT, command=lambda:raise_frame(root2))
	addFace.pack(ipadx=10)
else:
	print("It means it is going to START!")
	Thread(target=startLogin).start()
	
#status of add face
faceStatus = Label(root1, text='(Face Not Detected)', font=('Arial 10'), fg=textColor, bg=background)
faceStatus.pack(pady=5)

##################################
########  FACE ADD SCREEN  #######
##################################

image2 = Image.open('assets/images/defaultFace4.png')
image2 = image2.resize((300, 250))
defaultImg2 = ImageTk.PhotoImage(image2)

dataFrame2 = Frame(root2, bd=10, bg=background)
dataFrame2.pack(fill=X)
lmain = Label(dataFrame2, width=300, height=250, image=defaultImg2)
lmain.pack(padx=10, pady=10)

#Details
detailFrame2 = Frame(root2, bd=10, bg=background)
detailFrame2.pack(fill=X)
userFrame2 = Frame(detailFrame2, bd=10, width=300, height=250, relief=FLAT, bg=background)
userFrame2.pack(padx=10, pady=10)

#progress
progress_bar = ttk.Progressbar(root2, orient=HORIZONTAL, length=303, mode='determinate')

#name
nameLbl = Label(userFrame2, text='Name', font=('Arial Bold', 12), fg='#303E54', bg=background)
nameLbl.place(x=10,y=10)
nameField = Entry(userFrame2, bd=5, font=('Arial Bold', 10), width=25, relief=FLAT, bg='#D4D5D7')
nameField.focus()
nameField.place(x=80,y=10)

genLbl = Label(userFrame2, text='Gender', font=('Arial Bold', 12), fg='#303E54', bg=background)
genLbl.place(x=10,y=50)
r = IntVar()
s = ttk.Style()
s.configure('Wild.TRadiobutton', background=background, foreground=textColor, font=('Arial Bold', 10), focuscolor=s.configure(".")["background"])
genMale = ttk.Radiobutton(userFrame2, text='Male', value=1, variable=r, style='Wild.TRadiobutton', takefocus=False)
genMale.place(x=80,y=52)
genFemale = ttk.Radiobutton(userFrame2, text='Female', value=2, variable=r, style='Wild.TRadiobutton', takefocus=False)
genFemale.place(x=150,y=52)

#agreement
agr = IntVar()
sc = ttk.Style()
sc.configure('Wild.TCheckbutton', background=background, foreground='#303E54', font=('Arial Bold',10), focuscolor=sc.configure(".")["background"])
# agree = Checkbutton(userFrame2, text='I agree to use my face for Security purpose', fg=textColor, bg=background, activebackground=background, activeforeground=textColor)
agree = ttk.Checkbutton(userFrame2, text='I agree to use my Face for Security', style='Wild.TCheckbutton', takefocus=False, variable=agr)
agree.place(x=28, y=100)
#add face
addBtn = Button(userFrame2, text='    Add Face    ', font=('Arial Bold', 12), bg='#01933B', fg='white', command=Add_Face, relief=FLAT)
addBtn.place(x=90, y=150)

#status of add face
statusLbl = Label(userFrame2, text='', font=('Arial 10'), fg=textColor, bg=background)
statusLbl.place(x=80, y=190)

##########################
#### QR-Code ####
##########################
image3 = Image.open('info.png')
image3 = image3.resize((300, 250))
defaultImg3 = ImageTk.PhotoImage(image3)

dataFrame3 = Frame(root3, bd=10, bg=background)
dataFrame3.pack(fill=X)
label_widget = Label(dataFrame3,width=300, height=250,image=defaultImg3)
label_widget.pack()

#details

detailFrame3 = Frame(root3, bd=10, bg=background)
detailFrame3.pack(fill=X)
userFrame3 = Frame(detailFrame3, bd=10, width=300, height=600,relief=FLAT, bg=background)
userFrame3.pack()


Qrcode = Label(userFrame3, text="            QR code Recognition ", font=('Arial Bold', 12), fg='#303E54', bg=background)
Qrcode.place(x = 0, y = 10)


fullname = Label(userFrame3, text="Full name :", font=('Arial Bold', 12), fg='#303E54', bg=background)
fullname.place(x=0,y=50)
fullnamentry = Entry(userFrame3, textvariable=StringVar(), bd=5, font=('Arial Bold', 10), width=25, relief=RIDGE, bg='#D4D5D7')
fullnamentry.focus()
fullnamentry.place(x=100,y=50)


Age = Label(userFrame3, text='Age :', font=('Arial Bold', 12), fg='#303E54', bg=background)
Age.place(x=45,y=90)
agentry = Entry(userFrame3,textvariable=IntVar(), bd=5, font=('Arial Bold', 10), width=25, relief=RIDGE, bg='#D4D5D7')
agentry.place(x=100,y=90)


Mail = Label(userFrame3, text='Mail :', font=('Arial Bold', 12), fg='#303E54', bg=background)
Mail.place(x=45,y=130)
mailentry = Entry(userFrame3, textvariable=StringVar(), bd=5, font=('Arial Bold', 10), width=25, relief=RIDGE, bg='#D4D5D7')
mailentry.place(x=100,y=130)


# # NOTE STEPS #
# imp_head = Label(userFrame3,anchor = NW, text = "*Note*",font=('Arial Bold', 8), fg='black', bg=background) 
# imp_head.place(x = 0, y = 275 )

# details = Label(userFrame3,anchor = NW, text = "This is the second step of 2-factor Authentication \n process                                                                             ",font=('Arial Bold', 8), fg='#303E54', bg=background) 
# details.place(x = 0, y = 300 )

# step1 = Label(userFrame3, text = "1)Enter your full name correctly. ",font=('Arial Bold', 8), fg='#303E54', bg=background) 
# step1.place(x = 0, y = 340 )

# step2 = Label(userFrame3, text = "2)Enter your age and email correctly and submit   \n the details withoutfail.                                              ",font=('Arial Bold', 8), fg='#303E54', bg=background) 
# step2.place(x = 0, y = 360 )

# step3 = Label(userFrame3, text = "3)An QR code will be sent to your email kindly             \n scan it for verification then here you Go!                  ",font=('Arial Bold', 8), fg='#303E54', bg=background) 
# step3.place(x = 0, y = 395 )


button = Button(userFrame3, text = "Submit Data",font=('Arial Bold', 12), bg='#01933B', fg='white', bd=0, relief=RAISED, activebackground="lightgreen", command = save_info)
button.place( x = 100,y = 170)

nextbutton = Button(userFrame3, text = "Next",font=('Arial Bold', 12), bg='#01933B', fg='white', bd=0, relief=RAISED,activebackground="lightgreen", command = update)#, command = lambda:raise_frame(root4)
nextbutton.place( x = 125,y = 210)

#save_info detals warning
fillwarn = Label(userFrame3, text='', font=('Arial 10'), fg="Red", bg=background)
fillwarn.place(x=60, y=240)


#########################################
######## SUCCESSFULL REGISTRATION #######
#########################################


userPIC = Label(root4, bg=background)
userPIC.pack(pady=(40, 10))
usernameLbl = Label(root4, text="TVS Bank", font=('Arial Bold',15), bg=background, fg='#85AD4F')
usernameLbl.pack(pady=(0, 70))

Label(root4, text="Your account has been successfully activated!", font=('Arial Bold',15), bg=background, fg='#303E54', wraplength=300).pack(pady=10)
Label(root4, text="Launch the APP again to get started the conversation with your Personal Assistant", font=('arial',13), bg=background, fg='#A3A5AB', wraplength=350).pack()

Button(root4, text='     OK     ', bg='#0475BB', fg='white',font=('Arial Bold', 18), bd=0, relief=FLAT, command=lambda:quit()).pack(pady=50)

root.iconbitmap('assets/images/assistant2.ico')

raise_frame(root1)
root.mainloop()