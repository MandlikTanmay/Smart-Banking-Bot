from tkinter import *
def save_info_to_text_1():

    def save_info():

        first_name_info = first_name_text.get()

        last_name_info =  last_name_text.get()

        age_info = age_text.get()

        mail_info = mail_text.get()

        print(first_name_info,last_name_info,age_info,mail_info)

        file = open("QR code\Tanmay.text","w")

        file.write("Your First Name : " + first_name_info)

        file.write("\n")

        file.write("Your Last Name : " + last_name_info)

        file.write("\n")

        file.write("your Age : "+ str(age_info))

        file.close()

        file1 = open("QR code\Tanmay.txt","w")

        file1.write(mail_info)

        file1.close()

    app = Tk()

    app.geometry("400x550")

    app.title("Banking Bot")
    
    heading = Label(text = "QR Code Authentication ",bg = "#385ad3",fg = "black",font = 'Helvetica 18 bold',width = "500",height = '2')
    
    heading.pack()

    first_name_text = Label(text = "First name : ")
    last_name_text = Label(text = "Lastname : ")
    age_text = Label(text = "Age : ")
    mail_text = Label(text = "Mail : ")

    first_name_text.place(x = 15,y = 70)
    last_name_text.place(x = 15,y = 120)
    age_text.place(x = 15,y = 170)
    mail_text.place(x = 15,y = 220)

    first_name_text = StringVar()
    last_name_text = StringVar()
    age_text = IntVar()
    mail_text = StringVar()


    first_name_entry = Entry(textvariable=first_name_text,width="30")
    last_name_text =Entry(textvariable=last_name_text,width="30")
    age_entry = Entry(textvariable=age_text,width= "30")
    mail_entry = Entry(textvariable=mail_text,width= "30")


    first_name_entry.place(x = 15,y = 100)
    last_name_text.place(x = 15,y =150)
    age_entry.place(x = 15,y = 200)
    mail_entry.place(x =15, y = 250)

    button = Button(app,text = "Submit Data",command = save_info,width = "30",height ="2",bg = "grey")
    button.place( x = 15,y = "320")

    button = Button(app,text = "Click to Exit",command = app.destroy,width = "30",height = "2",bg = "grey")
    button.place( x = 15,y = "360")

    mainloop()


def Generator_2():
    import qrcode
    with open('QR code\Tanmay.text',"r") as fname:
        data = fname.readlines()   
        print(data)
    string = ''.join(data)
    print(string)

    features =qrcode.QRCode(version = 2,box_size = 20,border = 3)
        
    features.add_data(string)
    features.make(fit =True)
    generate_image = features.make_image(fill_color = "black",back_color = 'White')
    generate_image.save ('QR code\QR-Code.png')

def send_attachment_3():
    import smtplib
    import re
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders

    with open('QR code\Tanmay.txt',"r") as fname:
        data = fname.readlines()   
        print(data)
    string = ''.join(data)
    print(string)
    clean_data = string 

    remove_blank_space= re.sub(r'\s+', '', clean_data)

    print(remove_blank_space)

    fromaddr = "tanmaymandlik974@gmail.com"
    password = "morndvawglogegpj"
    toaddr = remove_blank_space

    msg = MIMEMultipart()

    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Scan Quick Response Code For Futher Authentication Process"

    body = "Body_of_the_mail"

    msg.attach(MIMEText(body, 'image'))

    filename = "QR code\QR-Code.png"
    attachment = open("QR code\QR-Code.png", "rb")

    p = MIMEBase('application', 'octet-stream')

    p.set_payload((attachment).read())

    encoders.encode_base64(p)

    p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    msg.attach(p)

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(fromaddr,password)

    text1 = msg.as_string()

    server.send_message(msg)

    server.quit()
def scanner_4():
   import cv2
   import io
   with open('QR code\Tanmay.text',"r") as fname:
      data = fname.readlines()
      print(data)
   string = ''.join(data)
   print(string)
   cap = cv2.VideoCapture(0)
   detector = cv2.QRCodeDetector()
   while True:
      __,img = cap.read()
      data,one, _= detector.detectAndDecode(img)
      if data:
         a = data
         file_obj = io.StringIO(a)
         contents = file_obj.read()
         # print(contents)
         if contents == string:
            print("Successfull!")
            break
      cv2.imshow('QR-code Scanner',img)
   cap.release()
   cv2.destroyAllWindows()


try:
    save_info_to_text_1()
    Generator_2()
    send_attachment_3()
    scanner_4()
    
except Exception as e:
	print(e)
