import tkinter as tk
import cv2
from PIL import Image, ImageTk

def open_camera():
    with open('QR code\Tanmay.text', "r") as fname:
        data = fname.readlines()
    string = ''.join(data)
    detector = cv2.QRCodeDetector()
    _, frame = cap.read()
    data, _, _ = detector.detectAndDecode(frame)
    if data:
        a = data
        contents = a.strip()  
        if contents == string:
            print("Successful!")
        else:
            print("Match not found")
            
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    captured_image = Image.fromarray(frame_rgb)
    photo_image = ImageTk.PhotoImage(image=captured_image)
    label_widget.photo_image = photo_image
    label_widget.configure(image=photo_image)
    label_widget.after(10, open_camera)

cap = cv2.VideoCapture(0)
width, height = 200, 200
cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

root = tk.Tk()
root.title("Camera App")

label_widget = tk.Label(root)
label_widget.pack()

# button1 = tk.Button(root, text="Open Camera", command=open_camera)
# button1.pack()
button = tk.Button(root, text = "Next",font=('Arial Bold', 12), bg='#01933B', fg='white', bd=0,activebackground="lightgreen", command = open_camera)#, command = lambda:raise_frame(root4)
button.pack()

root.bind('<Escape>', lambda e: root.quit())

root.mainloop()